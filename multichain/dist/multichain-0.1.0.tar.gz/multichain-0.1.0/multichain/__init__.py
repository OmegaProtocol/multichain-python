# -*- coding: utf-8 -*-
"""
Created on Wed Jun 14 09:52:13 2017

@author: 50063023
"""

__all__ = ['multichain']
# deprecated to keep older scripts who import this from breaking
from multichain.multichain import *
